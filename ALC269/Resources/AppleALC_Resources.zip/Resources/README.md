# AppleALC Layout files
- Resources Folder for compiling AppleALC.kext with Layout-IDs 18 and 39 for Realtek ALC269 only.
- **Resulting File siz**e: 95 kB
- **Layout-ID 18**: for normal use of the T530
- **Layout-ID 39**: for using the Line-Out and Line-In T530 of Dockingstations 4337 or 4338. For using the Line-In you have to switch it manually in System Settings.
- This kext is used in my EFI Folder

## Credits and Resources
- Acidanthera for AppleALC and Lilu
- Guide for [compiling a Slimmed Down AppleALC kext](https://github.com/5T33Z0/OC-Little-Translated/blob/main/L_ALC_Layout-ID/Slimming_AppleALC.md)
